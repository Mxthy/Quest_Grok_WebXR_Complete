/**
 * WebXR client adapter (KB: life-vibe/architecture/platform-adapters,
 * life-vibe/webxr/iwsdk, life-vibe/threejs/webgl2-xr).
 *
 * Simulation / gameplay must NOT import WebXR session or controller APIs.
 * This module is the only place that talks to renderer.xr / XRSession.
 *
 * Path: Meta WebXR feature detection + Three.js WebGLRenderer.xr
 * (Immersive Web SDK oriented boundary; raw XR stays here).
 */
import * as THREE from "three";
import { XRSessionManager, type XRSessionInfo } from "@/xr/XRSessionManager";
import { XRPlayerRig } from "@/xr/XRPlayerRig";
import { QuestControllerLayer } from "@/xr/QuestControllerLayer";
import { LocomotionSystem } from "@/xr/Locomotion";
import { XRDiagnostics, type XRDiagSnapshot } from "@/xr/XRDiagnostics";
import { VRWorldUI } from "@/xr/VRWorldUI";
import {
  loadComfort,
  type VRComfortConfig,
} from "@/xr/VRComfortSettings";
import { emptyActions, type ActionState } from "@/xr/InputActions";
import { getCapabilities, probeImmersiveVR } from "@/platform/PlatformCapabilities";

/** Engineering budget from KB life-vibe/performance/quest3-budgets — measure on device */
export const QUEST_TARGET_FPS = 72;
export const QUEST_FRAME_BUDGET_MS = 1000 / QUEST_TARGET_FPS;

export type WebXRFrameResult = {
  presenting: boolean;
  actions: ActionState;
  /** primary controller ray when presenting */
  hasRay: boolean;
  rayOrigin: THREE.Vector3;
  rayDirection: THREE.Vector3;
  /** logical feet after locomotion */
  feet: THREE.Vector3;
  yaw: number;
  eyeHeight: number;
};

export type WebXRClient = {
  init(): Promise<boolean>;
  enterImmersive(): Promise<boolean>;
  exitImmersive(): Promise<void>;
  isPresenting(): boolean;
  getSessionInfo(): XRSessionInfo;
  /** Call once per animation frame before simulation consumes actions */
  tick(dt: number, opts: {
    collide: (pos: THREE.Vector3, radius: number) => void;
    isWalkable: (x: number, z: number) => boolean;
    allowMove: boolean;
  }): WebXRFrameResult;
  showPrompt(text: string, worldPos: THREE.Vector3, camera: THREE.Camera): void;
  hidePrompt(): void;
  pulseHaptic(hand: "left" | "right", intensity?: number, ms?: number): void;
  getDiagnostics(extra?: Partial<XRDiagSnapshot>): XRDiagSnapshot;
  getComfort(): VRComfortConfig;
  reloadComfort(): void;
  /** Sync desktop player into rig when not presenting */
  syncFromDesktop(x: number, z: number, yaw: number): void;
  getRigPosition(): THREE.Vector3;
  dispose(): void;
};

export function createWebXRClient(
  renderer: THREE.WebGLRenderer,
  scene: THREE.Scene,
  camera: THREE.PerspectiveCamera,
): WebXRClient {
  // KB: renderer owns XR plumbing
  renderer.xr.enabled = true;
  try {
    if (getCapabilities().platform === "quest") {
      renderer.setPixelRatio(1);
      renderer.shadowMap.enabled = false;
    }
  } catch {
    /* */
  }

  const session = new XRSessionManager(renderer);
  const rig = new XRPlayerRig(camera);
  rig.setPosition(2.85, 4.25, 0);
  scene.add(rig.group);

  const controllers = new QuestControllerLayer(renderer, scene);
  const locomotion = new LocomotionSystem(scene);
  const diag = new XRDiagnostics();
  const worldUI = new VRWorldUI(scene);
  let comfort = loadComfort();

  const rayOrigin = new THREE.Vector3();
  const rayDirection = new THREE.Vector3(0, 0, -1);
  const feet = new THREE.Vector3();

  return {
    async init() {
      await probeImmersiveVR();
      return session.init();
    },

    enterImmersive: () => session.start(),
    exitImmersive: () => session.end(),
    isPresenting: () => session.isPresenting(),
    getSessionInfo: () => session.getInfo(),

    tick(dt, opts) {
      diag.tick(dt);
      comfort = loadComfort();
      const presenting = session.isPresenting();
      let actions = emptyActions();

      if (presenting) {
        controllers.update();
        actions = controllers.toActions();
        if (opts.allowMove) {
          locomotion.update(
            dt,
            actions,
            rig,
            comfort,
            true,
            controllers,
            opts.collide,
            opts.isWalkable,
          );
        }
        const ok = controllers.getPrimaryRay(rayOrigin, rayDirection);
        feet.copy(rig.position);
        return {
          presenting: true,
          actions,
          hasRay: ok,
          rayOrigin: rayOrigin.clone(),
          rayDirection: rayDirection.clone(),
          feet: feet.clone(),
          yaw: rig.yaw,
          eyeHeight: rig.height + comfort.heightOffset,
        };
      }

      feet.copy(rig.position);
      return {
        presenting: false,
        actions: emptyActions(),
        hasRay: false,
        rayOrigin: rayOrigin.clone(),
        rayDirection: rayDirection.clone(),
        feet: feet.clone(),
        yaw: rig.yaw,
        eyeHeight: rig.height + comfort.heightOffset,
      };
    },

    showPrompt(text, worldPos, cam) {
      worldUI.show(text, worldPos, cam);
    },
    hidePrompt() {
      worldUI.hide();
    },
    pulseHaptic(hand, intensity = 0.6, ms = 40) {
      try {
        controllers.pulse(hand, intensity, ms);
      } catch {
        /* haptic optional */
      }
    },
    getDiagnostics(extra) {
      const info = session.getInfo();
      return diag.snapshot({
        xrSession: info.state,
        referenceSpace: info.referenceSpaceType,
        leftController: controllers.left.connected ? "OK" : "—",
        rightController: controllers.right.connected ? "OK" : "—",
        trigger:
          controllers.left.triggerPressed || controllers.right.triggerPressed
            ? "ON"
            : "off",
        grip:
          controllers.left.squeezePressed || controllers.right.squeezePressed
            ? "ON"
            : "off",
        thumbstick: `L ${controllers.left.thumbstick.x.toFixed(1)},${controllers.left.thumbstick.y.toFixed(1)}`,
        presenting: session.isPresenting(),
        ...extra,
      });
    },
    getComfort: () => comfort,
    reloadComfort: () => {
      comfort = loadComfort();
    },
    syncFromDesktop(x, z, yaw) {
      if (!session.isPresenting()) {
        rig.commitPosition(x, z);
        rig.setYaw(yaw);
      }
    },
    getRigPosition: () => rig.position.clone(),
    dispose() {
      try {
        session.dispose();
      } catch {
        /* */
      }
      try {
        controllers.dispose();
      } catch {
        /* */
      }
      try {
        locomotion.dispose();
      } catch {
        /* */
      }
      try {
        worldUI.dispose();
      } catch {
        /* */
      }
      scene.remove(rig.group);
    },
  };
}
