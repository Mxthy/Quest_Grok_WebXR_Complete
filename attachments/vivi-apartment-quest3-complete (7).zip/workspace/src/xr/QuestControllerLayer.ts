/**
 * Quest controller input → unified ActionState.
 * Does not call gameplay directly.
 */
import * as THREE from "three";
import { emptyActions, type ActionState } from "@/xr/InputActions";

export type ControllerHand = "left" | "right";

export type ControllerSnapshot = {
  connected: boolean;
  position: THREE.Vector3;
  quaternion: THREE.Quaternion;
  /** ray origin ≈ controller */
  rayOrigin: THREE.Vector3;
  rayDirection: THREE.Vector3;
  trigger: number;
  triggerPressed: boolean;
  squeeze: number;
  squeezePressed: boolean;
  thumbstick: { x: number; y: number };
  buttonA: boolean;
  buttonB: boolean;
  /** XRTargetRaySpace object from three */
  targetRay: THREE.Object3D | null;
  grip: THREE.Object3D | null;
};

const _q = new THREE.Quaternion();
const _dir = new THREE.Vector3(0, 0, -1);

function emptySnap(): ControllerSnapshot {
  return {
    connected: false,
    position: new THREE.Vector3(),
    quaternion: new THREE.Quaternion(),
    rayOrigin: new THREE.Vector3(),
    rayDirection: new THREE.Vector3(0, 0, -1),
    trigger: 0,
    triggerPressed: false,
    squeeze: 0,
    squeezePressed: false,
    thumbstick: { x: 0, y: 0 },
    buttonA: false,
    buttonB: false,
    targetRay: null,
    grip: null,
  };
}

export class QuestControllerLayer {
  left = emptySnap();
  right = emptySnap();
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private prevTrigger = { left: false, right: false };
  private prevSqueeze = { left: false, right: false };
  private prevA = false;
  private prevB = false;
  private prevY = false;
  private prevX = false;
  private controllers: THREE.XRTargetRaySpace[] = [];
  private grips: THREE.XRGripSpace[] = [];
  private lines: THREE.Line[] = [];

  constructor(renderer: THREE.WebGLRenderer, scene: THREE.Scene) {
    this.renderer = renderer;
    this.scene = scene;
    this.setupControllers();
  }

  private setupControllers() {
    for (let i = 0; i < 2; i++) {
      const ctrl = this.renderer.xr.getController(i);
      const grip = this.renderer.xr.getControllerGrip(i);
      this.scene.add(ctrl);
      this.scene.add(grip);
      this.controllers.push(ctrl);
      this.grips.push(grip);

      // ray line visual
      const geo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(0, 0, 0),
        new THREE.Vector3(0, 0, -1.2),
      ]);
      const mat = new THREE.LineBasicMaterial({
        color: 0xa8c0ff,
        transparent: true,
        opacity: 0.55,
        depthWrite: false,
      });
      const line = new THREE.Line(geo, mat);
      line.scale.z = 1;
      line.visible = false;
      ctrl.add(line);
      this.lines.push(line);

      // tip marker
      const tip = new THREE.Mesh(
        new THREE.SphereGeometry(0.012, 8, 8),
        new THREE.MeshBasicMaterial({ color: 0xffffff }),
      );
      tip.position.z = -1.2;
      ctrl.add(tip);
    }
  }

  setRayVisible(visible: boolean) {
    for (const l of this.lines) l.visible = visible;
  }

  private readGamepad(src: XRInputSource | undefined, hand: ControllerHand): void {
    const snap = hand === "left" ? this.left : this.right;
    if (!src?.gamepad) {
      snap.trigger = 0;
      snap.triggerPressed = false;
      snap.squeeze = 0;
      snap.squeezePressed = false;
      snap.thumbstick = { x: 0, y: 0 };
      snap.buttonA = false;
      snap.buttonB = false;
      return;
    }
    const gp = src.gamepad;
    const buttons = gp.buttons ?? [];
    // standard XR mapping: 0=trigger, 1=squeeze, 3=thumbstick click, 4=A/X, 5=B/Y
    snap.trigger = buttons[0]?.value ?? 0;
    snap.triggerPressed = buttons[0]?.pressed ?? snap.trigger > 0.75;
    snap.squeeze = buttons[1]?.value ?? 0;
    snap.squeezePressed = buttons[1]?.pressed ?? snap.squeeze > 0.75;
    const axes = gp.axes ?? [];
    // axes 2,3 often thumbstick on Quest
    const ax = axes.length >= 4 ? axes[2]! : axes[0] ?? 0;
    const ay = axes.length >= 4 ? axes[3]! : axes[1] ?? 0;
    snap.thumbstick = {
      x: deadzone(ax),
      y: deadzone(-ay), // forward positive
    };
    if (hand === "right") {
      snap.buttonA = buttons[4]?.pressed ?? false;
      snap.buttonB = buttons[5]?.pressed ?? false;
    } else {
      snap.buttonA = buttons[4]?.pressed ?? false; // X
      snap.buttonB = buttons[5]?.pressed ?? false; // Y
    }
  }

  /** Call each frame while presenting */
  update(): void {
    const session = this.renderer.xr.getSession();
    const sources = session?.inputSources ? Array.from(session.inputSources) : [];

    for (let i = 0; i < 2; i++) {
      const ctrl = this.controllers[i]!;
      const grip = this.grips[i]!;
      const hand: ControllerHand = i === 0 ? "left" : "right";
      const snap = hand === "left" ? this.left : this.right;

      // match handedness if available
      let src: XRInputSource | undefined;
      for (const s of sources) {
        if (s.handedness === hand) {
          src = s;
          break;
        }
      }
      if (!src && sources[i]) src = sources[i];

      snap.targetRay = ctrl;
      snap.grip = grip;
      snap.connected = !!src || ctrl.visible;

      ctrl.getWorldPosition(snap.position);
      ctrl.getWorldQuaternion(snap.quaternion);
      snap.rayOrigin.copy(snap.position);
      _dir.set(0, 0, -1).applyQuaternion(snap.quaternion).normalize();
      snap.rayDirection.copy(_dir);

      this.readGamepad(src, hand);
      this.lines[i]!.visible = this.renderer.xr.isPresenting;
    }
  }

  /**
   * Map controller state → ActionState for this frame.
   * Left stick: move, Right stick: turn / teleport hold
   * Trigger: interact, Grip: grab, A: photo, B: menu, Y: inventory
   */
  toActions(): ActionState {
    const a = emptyActions();
    const L = this.left;
    const R = this.right;

    // movement from left stick
    a.moveX = L.thumbstick.x;
    a.moveY = L.thumbstick.y;

    // turn from right stick X
    a.turnX = R.thumbstick.x;
    a.turnY = R.thumbstick.y;

    // teleport: right stick forward held
    a.teleportHeld = R.thumbstick.y > 0.65;
    a.teleport = a.teleportHeld; // edge handled by locomotion layer

    // trigger → interact (prefer dominant / either)
    const trigNow = L.triggerPressed || R.triggerPressed;
    const trigEdge =
      (L.triggerPressed && !this.prevTrigger.left) ||
      (R.triggerPressed && !this.prevTrigger.right);
    a.interactHeld = trigNow;
    a.interact = trigEdge;

    const sqNow = L.squeezePressed || R.squeezePressed;
    const sqEdge =
      (L.squeezePressed && !this.prevSqueeze.left) ||
      (R.squeezePressed && !this.prevSqueeze.right);
    a.grabHeld = sqNow;
    a.grab = sqEdge;

    // buttons
    a.photo = R.buttonA && !this.prevA;
    a.menu = R.buttonB && !this.prevB;
    a.inventory = L.buttonB && !this.prevY;
    a.back = L.buttonA && !this.prevX;

    this.prevTrigger.left = L.triggerPressed;
    this.prevTrigger.right = R.triggerPressed;
    this.prevSqueeze.left = L.squeezePressed;
    this.prevSqueeze.right = R.squeezePressed;
    this.prevA = R.buttonA;
    this.prevB = R.buttonB;
    this.prevY = L.buttonB;
    this.prevX = L.buttonA;

    return a;
  }

  /** Primary interaction ray (prefer right, else left) */
  getPrimaryRay(outOrigin: THREE.Vector3, outDir: THREE.Vector3): boolean {
    const primary = this.right.connected ? this.right : this.left.connected ? this.left : null;
    if (!primary) return false;
    outOrigin.copy(primary.rayOrigin);
    outDir.copy(primary.rayDirection);
    return true;
  }

  /** Pulse haptic if actuator available */
  pulse(hand: ControllerHand, intensity = 0.6, durationMs = 40): void {
    try {
      const session = this.renderer.xr.getSession();
      if (!session) return;
      for (const src of session.inputSources) {
        if (src.handedness !== hand) continue;
        const actuators = (src.gamepad as Gamepad & { hapticActuators?: { pulse: (i: number, d: number) => Promise<boolean> }[] })
          ?.hapticActuators;
        const act = actuators?.[0];
        if (act?.pulse) void act.pulse(intensity, durationMs);
        // also try vibrationActuator
        const vib = src.gamepad?.vibrationActuator;
        if (vib?.playEffect) {
          void vib.playEffect("dual-rumble", {
            startDelay: 0,
            duration: durationMs,
            weakMagnitude: intensity,
            strongMagnitude: intensity,
          });
        }
      }
    } catch {
      /* haptic optional */
    }
  }

  dispose() {
    for (const c of this.controllers) {
      this.scene.remove(c);
    }
    for (const g of this.grips) {
      this.scene.remove(g);
    }
  }
}

function deadzone(v: number, z = 0.15): number {
  if (Math.abs(v) < z) return 0;
  const s = Math.sign(v);
  return s * ((Math.abs(v) - z) / (1 - z));
}
