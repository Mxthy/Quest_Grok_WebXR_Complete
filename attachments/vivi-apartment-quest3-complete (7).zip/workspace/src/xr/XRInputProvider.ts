/**
 * Abstract XR input providers — Controller vs HandTracking.
 * Engine only consumes ActionState + rays.
 */
import type { ActionState } from "@/xr/InputActions";
import type * as THREE from "three";

export interface XRInputProvider {
  readonly id: string;
  update(): void;
  toActions(): ActionState;
  getPrimaryRay(origin: THREE.Vector3, dir: THREE.Vector3): boolean;
  pulse?(hand: "left" | "right", intensity?: number, ms?: number): void;
  dispose(): void;
}

/** Placeholder hand-tracking provider — ready for future implementation */
export class HandTrackingProvider implements XRInputProvider {
  readonly id = "hand-tracking";
  private enabled = false;

  setEnabled(on: boolean) {
    this.enabled = on;
  }

  update(): void {
    /* future: read XRHand joints */
  }

  toActions(): ActionState {
    // no-op until joints wired
    return {
      moveX: 0,
      moveY: 0,
      turnX: 0,
      turnY: 0,
      interact: false,
      interactHeld: false,
      grab: false,
      grabHeld: false,
      teleport: false,
      teleportHeld: false,
      menu: false,
      back: false,
      photo: false,
      inventory: false,
      sprint: false,
    };
  }

  getPrimaryRay(_o: THREE.Vector3, _d: THREE.Vector3): boolean {
    return false;
  }

  dispose(): void {}
}
