/**
 * Comfort settings for Quest locomotion — persisted in localStorage.
 */

export type LocomotionMode = "smooth" | "teleport" | "both";
export type TurnMode = "snap" | "smooth";

export type VRComfortConfig = {
  locomotion: LocomotionMode;
  turn: TurnMode;
  moveSpeed: number;
  snapAngleDeg: number;
  smoothTurnSpeed: number;
  vignette: boolean;
  heightOffset: number;
  seated: boolean;
  teleportEnabled: boolean;
  smoothEnabled: boolean;
};

const KEY = "vivi-vr-comfort-v1";

export const DEFAULT_COMFORT: VRComfortConfig = {
  locomotion: "both",
  turn: "snap",
  moveSpeed: 1.6,
  snapAngleDeg: 45,
  smoothTurnSpeed: 1.8,
  vignette: true,
  heightOffset: 0,
  seated: false,
  teleportEnabled: true,
  smoothEnabled: true,
};

export function loadComfort(): VRComfortConfig {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULT_COMFORT };
    const parsed = JSON.parse(raw) as Partial<VRComfortConfig>;
    return { ...DEFAULT_COMFORT, ...parsed };
  } catch {
    return { ...DEFAULT_COMFORT };
  }
}

export function saveComfort(cfg: VRComfortConfig): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(cfg));
  } catch {
    /* quota / private mode */
  }
}

export function updateComfort(partial: Partial<VRComfortConfig>): VRComfortConfig {
  const next = { ...loadComfort(), ...partial };
  saveComfort(next);
  return next;
}
