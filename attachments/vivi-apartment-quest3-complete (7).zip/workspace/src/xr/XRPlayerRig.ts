/**
 * Player rig — movement is applied to the rig, not the XR camera directly.
 *
 * Structure:
 *   PlayerRig (Group)
 *     ├── camera parent (yaw)
 *     ├── Left controller (from renderer.xr)
 *     ├── Right controller
 *     └── collision capsule proxy (logical)
 */
import * as THREE from "three";

export type RigPose = {
  position: THREE.Vector3;
  yaw: number;
};

export class XRPlayerRig {
  readonly group: THREE.Group;
  /** logical feet position on floor */
  readonly position: THREE.Vector3;
  yaw = 0;
  height = 1.6;
  radius = 0.22;
  private camera: THREE.PerspectiveCamera;
  private _tmp = new THREE.Vector3();
  private _fwd = new THREE.Vector3();
  private _right = new THREE.Vector3();

  constructor(camera: THREE.PerspectiveCamera) {
    this.camera = camera;
    this.group = new THREE.Group();
    this.group.name = "XRPlayerRig";
    this.position = new THREE.Vector3(2.85, 0, 4.25);
    this.group.position.copy(this.position);
  }

  /** Spawn / recenter feet */
  setPosition(x: number, z: number, y = 0) {
    this.position.set(x, y, z);
    this.group.position.set(x, y, z);
  }

  setYaw(yaw: number) {
    this.yaw = yaw;
  }

  rotateYaw(delta: number) {
    this.yaw += delta;
    // keep in -PI..PI
    while (this.yaw > Math.PI) this.yaw -= Math.PI * 2;
    while (this.yaw < -Math.PI) this.yaw += Math.PI * 2;
  }

  /** Headset-relative forward (XZ), falling back to rig yaw when not presenting */
  getHeadForward(out: THREE.Vector3, presenting: boolean): THREE.Vector3 {
    if (presenting) {
      this.camera.getWorldDirection(out);
      out.y = 0;
      if (out.lengthSq() < 1e-6) {
        out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
      } else {
        out.normalize();
      }
    } else {
      out.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    }
    return out;
  }

  getHeadRight(out: THREE.Vector3, presenting: boolean): THREE.Vector3 {
    this.getHeadForward(this._fwd, presenting);
    out.crossVectors(this._fwd, new THREE.Vector3(0, 1, 0)).normalize();
    return out;
  }

  /**
   * Apply smooth locomotion in XZ relative to head.
   * Returns proposed position (caller applies collision).
   */
  proposeMove(
    moveX: number,
    moveY: number,
    speed: number,
    dt: number,
    presenting: boolean,
  ): THREE.Vector3 {
    this.getHeadForward(this._fwd, presenting);
    this.getHeadRight(this._right, presenting);
    const dist = speed * dt;
    this._tmp.copy(this.position);
    this._tmp.addScaledVector(this._fwd, moveY * dist);
    this._tmp.addScaledVector(this._right, moveX * dist);
    return this._tmp;
  }

  /** Commit position after collision resolution */
  commitPosition(x: number, z: number) {
    this.position.x = x;
    this.position.z = z;
    this.group.position.x = x;
    this.group.position.z = z;
  }

  /**
   * Desktop camera follow: place camera at eye height with yaw/pitch.
   * In XR, Three.js WebXR manages camera pose from the session.
   */
  applyDesktopCamera(pitch: number) {
    this.camera.position.set(
      this.position.x,
      this.position.y + this.height + 0 /* heightOffset applied outside */,
      this.position.z,
    );
    this.camera.rotation.order = "YXZ";
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = pitch;
    this.camera.rotation.z = 0;
  }

  /** Eye-level world position for interaction rays when not XR */
  getEyePosition(out: THREE.Vector3, heightOffset = 0): THREE.Vector3 {
    return out.set(
      this.position.x,
      this.position.y + this.height + heightOffset,
      this.position.z,
    );
  }

  getPose(): RigPose {
    return { position: this.position.clone(), yaw: this.yaw };
  }
}
