/**
 * Smooth locomotion, snap turn, teleport — operates on XRPlayerRig.
 */
import * as THREE from "three";
import type { XRPlayerRig } from "@/xr/XRPlayerRig";
import type { ActionState } from "@/xr/InputActions";
import type { VRComfortConfig } from "@/xr/VRComfortSettings";
import type { QuestControllerLayer } from "@/xr/QuestControllerLayer";

export type FloorProbe = (x: number, z: number) => boolean;

export type LocomotionResult = {
  moved: boolean;
  turned: boolean;
  teleported: boolean;
};

const _origin = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _hit = new THREE.Vector3();
const _tmp = new THREE.Vector3();

export class LocomotionSystem {
  private snapCool = 0;
  private teleportArmed = false;
  private teleportTarget: THREE.Vector3 | null = null;
  private marker: THREE.Mesh;
  private rayLine: THREE.Line;
  private scene: THREE.Scene;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.marker = new THREE.Mesh(
      new THREE.RingGeometry(0.18, 0.26, 24),
      new THREE.MeshBasicMaterial({
        color: 0x6ee7a8,
        transparent: true,
        opacity: 0.85,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    this.marker.rotation.x = -Math.PI / 2;
    this.marker.visible = false;
    scene.add(this.marker);

    const geo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(),
      new THREE.Vector3(0, 0, -1),
    ]);
    this.rayLine = new THREE.Line(
      geo,
      new THREE.LineBasicMaterial({ color: 0x6ee7a8, transparent: true, opacity: 0.5 }),
    );
    this.rayLine.visible = false;
    scene.add(this.rayLine);
  }

  update(
    dt: number,
    actions: ActionState,
    rig: XRPlayerRig,
    comfort: VRComfortConfig,
    presenting: boolean,
    controllers: QuestControllerLayer | null,
    collide: (pos: THREE.Vector3, radius: number) => void,
    isWalkable: FloorProbe,
  ): LocomotionResult {
    const result: LocomotionResult = { moved: false, turned: false, teleported: false };
    if (this.snapCool > 0) this.snapCool -= dt;

    // --- Snap / smooth turn ---
    if (comfort.turn === "snap") {
      if (Math.abs(actions.turnX) > 0.55 && this.snapCool <= 0) {
        const ang = (comfort.snapAngleDeg * Math.PI) / 180;
        rig.rotateYaw(-Math.sign(actions.turnX) * ang);
        this.snapCool = 0.28;
        result.turned = true;
      }
    } else {
      if (Math.abs(actions.turnX) > 0.12) {
        rig.rotateYaw(-actions.turnX * comfort.smoothTurnSpeed * dt);
        result.turned = true;
      }
    }

    // --- Smooth locomotion ---
    if (comfort.smoothEnabled && (comfort.locomotion === "smooth" || comfort.locomotion === "both")) {
      if (Math.abs(actions.moveX) > 0.05 || Math.abs(actions.moveY) > 0.05) {
        const proposed = rig.proposeMove(
          actions.moveX,
          actions.moveY,
          comfort.moveSpeed,
          dt,
          presenting,
        );
        collide(proposed, rig.radius);
        if (isWalkable(proposed.x, proposed.z)) {
          rig.commitPosition(proposed.x, proposed.z);
          result.moved = true;
        }
      }
    }

    // --- Teleport ---
    if (comfort.teleportEnabled && (comfort.locomotion === "teleport" || comfort.locomotion === "both")) {
      const aiming = actions.teleportHeld || actions.grabHeld;
      if (aiming && controllers) {
        const ok = controllers.getPrimaryRay(_origin, _dir);
        if (ok) {
          // parabolic-ish: intersect y=0 plane
          const t = _dir.y < -0.05 ? -(_origin.y - 0.02) / _dir.y : -1;
          if (t > 0.3 && t < 8) {
            _hit.copy(_origin).addScaledVector(_dir, t);
            const valid = isWalkable(_hit.x, _hit.z);
            this.teleportTarget = valid ? _hit.clone() : null;
            this.marker.visible = true;
            this.marker.position.set(_hit.x, 0.03, _hit.z);
            (this.marker.material as THREE.MeshBasicMaterial).color.setHex(
              valid ? 0x6ee7a8 : 0xf87171,
            );
            this.rayLine.visible = true;
            const pos = this.rayLine.geometry.attributes.position as THREE.BufferAttribute;
            pos.setXYZ(0, _origin.x, _origin.y, _origin.z);
            pos.setXYZ(1, _hit.x, _hit.y, _hit.z);
            pos.needsUpdate = true;
            this.teleportArmed = valid;
          } else {
            this.marker.visible = false;
            this.rayLine.visible = false;
            this.teleportArmed = false;
            this.teleportTarget = null;
          }
        }
      } else {
        if (this.teleportArmed && this.teleportTarget && !aiming) {
          // release → teleport
          const p = this.teleportTarget;
          _tmp.set(p.x, 0, p.z);
          collide(_tmp, rig.radius);
          if (isWalkable(_tmp.x, _tmp.z)) {
            rig.commitPosition(_tmp.x, _tmp.z);
            result.teleported = true;
          }
        }
        this.teleportArmed = false;
        this.teleportTarget = null;
        this.marker.visible = false;
        this.rayLine.visible = false;
      }
    } else {
      this.marker.visible = false;
      this.rayLine.visible = false;
    }

    return result;
  }

  dispose() {
    this.scene.remove(this.marker);
    this.scene.remove(this.rayLine);
    this.marker.geometry.dispose();
    (this.marker.material as THREE.Material).dispose();
    this.rayLine.geometry.dispose();
    (this.rayLine.material as THREE.Material).dispose();
  }
}
