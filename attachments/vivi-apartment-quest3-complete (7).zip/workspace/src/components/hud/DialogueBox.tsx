import { useEffect } from "react";
import { useGameStore } from "@/stores/gameStore";
import dialogues from "@/data/dialogues.json";
import type { DialogueNode } from "@/game/types";
import { Button } from "@/components/ui/button";
import type { IntimacyPace, IntimacyRegion } from "@/systems/intimacyNegotiation";

const nodes = (dialogues as { nodes: Record<string, DialogueNode> }).nodes;

/** Apply mutual-agreement side effects from dialogue choices / nodes */
function applyIntimacyEffects(nodeId: string, choiceId?: string) {
  const s = useGameStore.getState();

  // Consent yes paths
  if (
    nodeId === "consent_yes" ||
    nodeId === "negotiate_soft_yes" ||
    nodeId === "negotiate_region_torso" ||
    choiceId === "yes"
  ) {
    s.setConsent(true);
  }

  // Pace
  if (nodeId === "negotiate_pace_slow" || choiceId === "slow") s.setIntimacyPace("slow");
  if (nodeId === "negotiate_pace_medium" || choiceId === "medium") s.setIntimacyPace("medium");
  if (nodeId === "negotiate_pace_explore" || choiceId === "explore") s.setIntimacyPace("exploratory");

  // Regions opened by mutual yes
  if (nodeId === "negotiate_region_torso" || nodeId === "negotiate_soft_yes") {
    s.openIntimacyRegion("soft_torso");
  }
  if (nodeId === "negotiate_region_close_yes") {
    s.openIntimacyRegion("soft_torso");
    s.openIntimacyRegion("close");
  }
  if (nodeId === "consent_yes") {
    s.openIntimacyRegion("soft_torso");
  }
  if (nodeId === "vivi_curiosity_yes") {
    s.openIntimacyRegion("soft_torso");
    s.openIntimacyRegion("close");
    s.setConsent(true);
  }
  if (nodeId === "vivi_invite_soft_yes") {
    s.openIntimacyRegion("soft_torso");
    s.setConsent(true);
  }
  if (nodeId === "vivi_invite_declined") {
    s.respectIntimacyBoundary();
  }

  // Respecting stop / pause / wait builds trust
  if (
    nodeId === "pause_honored" ||
    nodeId === "touch_intimate_stop" ||
    nodeId === "touch_intimate_slow" ||
    nodeId === "negotiate_region_close_wait" ||
    nodeId === "negotiate_not_tonight" ||
    choiceId === "pause" ||
    choiceId === "stop" ||
    choiceId === "wait" ||
    choiceId === "slower"
  ) {
    s.respectIntimacyBoundary();
  }

  // Shared intimate moment
  if (
    nodeId === "touch_intimate_ask" ||
    nodeId === "touch_intimate_yes" ||
    nodeId === "check_in_more" ||
    nodeId === "aftercare_quiet"
  ) {
    s.noteSharedIntimacy();
  }

  // Not tonight / revoke closer
  if (nodeId === "negotiate_not_tonight") {
    // keep casual; revoke full consent for closer layers
    s.setConsent(false);
  }
}

export function DialogueBox() {
  const id = useGameStore((s) => s.dialogueId);
  const setDialogue = useGameStore((s) => s.setDialogue);
  const addStats = useGameStore((s) => s.addStats);
  const grantTutorial = useGameStore((s) => s.grantTutorial);
  const sleepToNextDay = useGameStore((s) => s.sleepToNextDay);
  const setConsent = useGameStore((s) => s.setConsent);
  const node = id ? nodes[id] : null;

  useEffect(() => {
    if (!node) return;
    if (node.grant?.length) grantTutorial();
    if (node.affection || node.comfort) {
      addStats({ affection: node.affection, comfort: node.comfort ?? 0 });
    }
    applyIntimacyEffects(node.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- fire once per node id
  }, [node?.id]);

  if (!node) return null;

  const continueNode = () => {
    if (node.id === "sleep_yes") sleepToNextDay();
    if (node.id === "consent_yes") setConsent(true);
    applyIntimacyEffects(node.id);
    if (node.next) setDialogue(node.next);
    else setDialogue(null);
  };

  return (
    <div className="pointer-events-auto absolute inset-x-0 bottom-0 z-30 flex justify-center p-3 pb-[max(1rem,env(safe-area-inset-bottom))] sm:p-6">
      <div className="w-full max-w-2xl rounded-xl border border-border bg-surface/95 p-4 shadow-overlay sm:p-5">
        <p className="font-display text-sm tracking-tight text-accent">{node.speaker}</p>
        <p className="mt-2 font-body text-base leading-normal text-fg">{node.text}</p>
        {node.choices?.length ? (
          <div className="mt-4 flex flex-col gap-2">
            {node.choices.map((c) => (
              <Button
                key={c.id}
                variant="secondary"
                className="h-auto min-h-11 justify-start py-2 text-left"
                onClick={() => {
                  if (c.affection) addStats({ affection: c.affection });
                  applyIntimacyEffects(node.id, c.id);
                  if (c.next === "sleep_yes") {
                    setDialogue("sleep_yes");
                    return;
                  }
                  if (c.next === "consent_yes" || c.id === "yes") {
                    setConsent(true);
                  }
                  setDialogue(c.next);
                }}
              >
                {c.label}
              </Button>
            ))}
          </div>
        ) : (
          <div className="mt-4 flex justify-end">
            <Button onClick={continueNode}>Continue</Button>
          </div>
        )}
      </div>
    </div>
  );
}
